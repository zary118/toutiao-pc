<template>
<div class="image-container">素材管理</div>
</template>

<script>
export default {
  name: 'ImageInsex',
  props: {},
  components: {},
  data () {
    return {}
  },
  computed: {},
  watch: {},
  methods: {}
}
</script>

<style scoped>

</style>
