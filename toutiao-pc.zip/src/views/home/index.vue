<template>
  <div class="home-container">
    首页
  </div>
</template>

<script>
export default {
  name: 'HomeIndex',
  props: {},
  components: {},
  data () {
    return {}
  },
  computed: {},
  watch: {},
  methods: {}
}
</script>

<style lang="less" scoped>
.home-container {
}
</style>
