<template>
<div class="comment-container">评论管理</div>
</template>

<script>
export default {
  name: 'CommentIndex',
  props: {},
  components: {},
  data () {
    return {}
  },
  computed: {},
  watch: {},
  methods: {}
}
</script>

<style scoped>

</style>
