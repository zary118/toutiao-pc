<template>
<div class="fans-container">粉丝管理</div>
</template>

<script>
export default {
  name: 'FansIndex',
  props: {},
  components: {},
  data () {
    return {}
  },
  computed: {},
  watch: {},
  methods: {}
}
</script>

<style scoped>

</style>
